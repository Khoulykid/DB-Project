from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import csv
import time

service = Service(executable_path="A:\chromedriver.exe")
options = Options()
options.add_argument('--headless')

driver = webdriver.Chrome(service=service, options = options)
link = "https://www.olx.com.eg/en/vehicles/cars-for-sale/cairo/?"
filter = "filter=new_used_eq_2%2Cyear_between_2000_to_2023"
i = 1
dates = ["second", "minute", "hour", "day", "week"]
carlinks = []
cardate = []
flag  = True
with open("Z:\DB\PROJECT\DB carlinks.csv", 'w', newline = '') as file:
    writer  =  csv.writer(file)
    while True:
        if i != 1:
            driver.get(link + "page=" + str(i) + "&" + filter)
        else:
            driver.get(link + filter)
        driver.implicitly_wait(30)
        cardate = driver.find_elements(By.CSS_SELECTOR, "#body-wrapper > div > header:nth-child(4) > div > div > div > div._1075545d.f21592b6.d059c029._858a64cf._1709dcb4 > div._1075545d._5fd4e59e._858a64cf > div.b884b783 > div._1075545d._96d4439a.d059c029._858a64cf > div._963450d6 > ul > li > article > div.a52608cc > div._4dbba078 > div._2fc90438 > span._2e28a695 > span")
        carlinks = driver.find_elements(By.CSS_SELECTOR, "#body-wrapper > div > header:nth-child(4) > div > div > div > div._1075545d.f21592b6.d059c029._858a64cf._1709dcb4 > div._1075545d._5fd4e59e._858a64cf > div.b884b783 > div._1075545d._96d4439a.d059c029._858a64cf > div._963450d6 > ul > li > article > div.ee2b0479 > a")
        for j in range(len(cardate)):
            if any(word in cardate[j].text for word in dates):
                writer.writerow([carlinks[j].get_attribute("href")])
            else:
                flag = False
                break
        if flag != True:
            break
        i += 1
file.close()
driver.quit()
    






