CREATE DATABASE IF NOT EXISTS OLX_DB;
USE OLX_DB;

SET GLOBAL local_infile = 1;
GRANT FILE ON *.* TO 'root'@'localhost';

CREATE TABLE IF NOT EXISTS Userprof(
Email varchar(50) primary key,
gender char(1) NOT NULL,
birth_date date NOT NULL,
username varchar(30) NOT NULL
);

CREATE TABLE IF NOT EXISTS preferences(
make varchar(30) NOT NULL,
model varchar(50) NOT NULL,
Email varchar(50) NOT NULL,
primary key(make, model, Email),
foreign key(Email) references Userprof(Email)
);

CREATE TABLE IF NOT EXISTS ownerprof(
RName varchar(50) not null,
join_date date NOT NULL,
PHNO varchar(13) primary key
);

CREATE TABLE IF NOT EXISTS PHNumber(
PHNO varchar(13) not null,
P_number varchar(13) NOT NULL,
primary key(PHNO, P_number),
foreign key(PHNO) references ownerprof(PHNO)
on delete cascade
on update cascade
);

CREATE TABLE IF NOT EXISTS Car_AD(
AD_ID int,
primary key(AD_ID),
PHNO varchar(250) NOT NULL,
foreign key(PHNO) references ownerprof(PHNO),
brand varchar(30) NOT NULL,
AD_type varchar(20),
price int NOT NULL,
pay_option varchar(15),
kilo_low int,
kilo_high int,
car_condition varchar(15),
Body_Type varchar(20),
Video varchar(20),
Model varchar(30),
Fuel_Type varchar(30),
Price_type varchar(30),
car_Year year,
Transmission varchar(25),
Color varchar(30),
Engine_low int,
Engine_high int,
Virtual_Tour varchar(30),
location varchar(200) NOT NULL,
descr varchar(1000)
);



CREATE TABLE IF NOT EXISTS Extra_Features(
AD_ID int NOT NULL,
feature varchar(100) NOT NULL,
primary key(feature, AD_ID),
foreign key(AD_ID) references Car_AD(AD_ID)
on delete cascade
on update no action
);


LOAD DATA INFILE "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/owners.csv"
IGNORE INTO TABLE ownerprof
CHARACTER SET utf8
FIELDS TERMINATED BY ','
OPTIONALLY enclosed by "'"
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(Rname, join_date, PHNO);

LOAD DATA INFILE "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Car_ADs.csv"
IGNORE INTO TABLE Car_AD
CHARACTER SET utf8
FIELDS TERMINATED BY '/'
OPTIONALLY enclosed by "'"
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(AD_ID,PHNO,brand,AD_type,price,pay_option,kilo_low,kilo_high,car_condition,Body_Type,Video,Model,Fuel_Type,Price_type,car_Year,Transmission,Color,Engine_low,Engine_high,Virtual_Tour,location,descr);


LOAD DATA INFILE "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Extra_Features.csv"
IGNORE INTO TABLE Extra_Features
CHARACTER SET utf8
FIELDS TERMINATED BY '/'
OPTIONALLY enclosed by "'"
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(AD_ID, feature);

LOAD DATA INFILE "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/PHnumbers.csv"
IGNORE INTO TABLE PHNumber
CHARACTER SET utf8
FIELDS TERMINATED BY '/'
OPTIONALLY enclosed by "'"
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(PHNO,P_number);

LOAD DATA INFILE "C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/PersonalUsers.csv"
IGNORE INTO TABLE Userprof
CHARACTER SET utf8
FIELDS TERMINATED BY ','
OPTIONALLY enclosed by "'"
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(birth_date, username, Email, gender);

