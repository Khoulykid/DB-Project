from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium_stealth import stealth
import csv
import time
import pyarabic.araby as araby
import pyarabic.number as number
user = "01119237416"
password = "uAnQpWizEjfZr7k"
row = {
    "AD_ID": None,
    "Seller_Ph_No": None,
    "brand": None,
    "AD_type": None,
    "price": None,
    "pay_option": None,
    "kilo_low": None,
    "kilo_high": None,
    "car_condition": None,
    "Body_Type": None,
    "Video": None,
    "Model": None,
    "Fuel_Type": None,
    "Price_type": None,
    "car_Year": None,
    "Transmission": None,
    "Color": None,
    "Engine_low": None,
    "Engine_high": None,
    "Virtual_Tour": None,
    "location": None,
    "description": None
}

options = webdriver.ChromeOptions()
options.add_argument("start-maximized")
options.add_argument(r'--user-data-dir=C:\\Users\\OmarElkhouly\AppData\\Local\\Google\\Chrome\\User Data\Default')
options.add_argument('--profile-directory=Profile 0')    
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option('useAutomationExtension', False)
options.add_argument('--ignore-certificate-errors')
options.add_argument('--ignore-ssl-errors')
service = Service(executable_path="A:\chromedriver.exe")
driver = webdriver.Chrome(service=service,options=options)
stealth(driver,
    languages=["en-US", "en"],
    vendor="Google Inc.",
    platform="Win32",
    webgl_vendor="Intel Inc.",
    renderer="Intel Iris OpenGL Engine",
    fix_hairline=True,)
links = open("Z:\DB\PROJECT\DB carlinks - Copy.csv", 'r', encoding='utf-8-sig').read().splitlines()

flag = True
for link in links:
    driver.get(link)
    time.sleep(3)
    
    # if flag:
    #      wait = WebDriverWait(driver, 10)
    #      login = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#body-wrapper > div._1075545d.d059c029._4c726bfa._1709dcb4 > header.c4388a34 > div > div._1075545d._17fba712._96d4439a > div > button > span")))
    #      login.click()
    #      login2 = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button.c6ce5164:nth-child(4) > span:nth-child(2)")))
    #      login2.click()
    #      type_phone = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#phone")))
    #      type_phone.send_keys(user)
    #      next1 = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".a755fcd9 > button:nth-child(2)")))
    #      next1.click()
    #      type_pass = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR,"#password" )))
    #      type_pass.send_keys(password)
    #      final = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button._5fd7b300:nth-child(4)")))
    #      final.click()
    #      time.sleep(5)
    #      flag = False
    
    try:
        driver.find_element(By.CSS_SELECTOR, "#body-wrapper > div._1075545d.d059c029._4c726bfa._1709dcb4 > header:nth-child(3) > div > div > div > div._0a9bc591 > div._408759e3 > div:nth-child(2) > div > div._1075545d.b34f9439._42f36e3b._96d4439a._1709dcb4 > span._09eb0c84._79855a31")
        AD_ID = driver.find_element(By.CSS_SELECTOR,'#body-wrapper > div > header:nth-child(3) > div > div > div > div._0a9bc591 > div._408759e3 > div._1075545d.c6bdd888._5f872d11 > div._171225da').text.removeprefix("AD ID ")
        row["AD_ID"] = AD_ID
        desc = driver.find_element(By.CSS_SELECTOR,'#body-wrapper > div > header:nth-child(3) > div > div > div > div._0a9bc591 > div.f4a99e5c > div:nth-child(2) > div:nth-child(2) > div > span').text
        row["description"] = desc.splitlines()
        details = driver.find_element(By.CSS_SELECTOR,"#body-wrapper > div > header:nth-child(3) > div > div > div > div._0a9bc591 > div.f4a99e5c > div:nth-child(2) > div:nth-child(1) > div").text.splitlines()
        for z in range(0, len(details), 2):
            attribute = details[z]
            value = details[z+1]
            if "Bra" in attribute:
                row["brand"] = value
            elif "Ad" in attribute:
                row["AD_type"] = value
            elif attribute == "Price" :
                value = value.replace(",", "")
                row["price"] = int(value)
            elif attribute == "Payment Options" :
                row["pay_option"] = value
            elif attribute == "Kilometers":
                if "to" in value:
                    parts = value.split(" to ")
                    row["kilo_low"] = int(parts[0])
                    row["kilo_high"] = int(parts[1])
                else:
                    num2 = ""
                    for c in value:
                        if c.isdigit():
                            num2 = num2 + c
                    row["kilo_low"] = 0
                    row["kilo_high"] = int(num2)
            elif attribute == "Condition":
                row["car_condition"] = value
            elif attribute == "Body Type":
                row["Body_Type"] = value
            elif attribute == "Video":
                row["Video"] = value
            elif attribute == "Model":
                row["Model"] = value
            elif attribute == "Fuel Type":
                row["Fuel_Type"] = value
            elif attribute == "Price Type":
                row["Price_type"] = value
            elif attribute == "Year":
                row["car_Year"] = int(value)
            elif attribute == "Transmission Type":
                row["Transmission"] = value
            elif attribute == "Color":
                row["Color"] = value
            elif attribute == "Engine Capacity (CC)":
                if value[0] == 'M':
                    value.replace("More than ", "")
                    row["Engine_high"] = int(value)
                    row["Engine_low"] = 0
                else:
                    parts = value.split(" - ")
                    if len(parts) > 1:
                        row["Engine_high"] = parts[1]
                        row["Engine_low"] = parts[0]
                    else:
                        row["Engine_high"] = int(value)
                        row["Engine_low"] = 0
            elif attribute == "Virtual Tour":
                row["Virtual_Tour"] = value

        row["location"] = driver.find_element(By.CSS_SELECTOR, "#body-wrapper > div > header:nth-child(3) > div > div > div > div._0a9bc591 > div._408759e3 > div:nth-child(5) > div > span.fccf2e37").text
        try:
            Extra_Features = driver.find_element(By.CSS_SELECTOR, "#body-wrapper > div > header:nth-child(3) > div > div > div > div._0a9bc591 > div.f4a99e5c > div:nth-child(2) > div:nth-child(3) > div > div").text.splitlines()
            with open("Z:\DB\PROJECT\Extra_Features.csv", 'a', newline="") as Ffile:
                writer = csv.DictWriter(Ffile, fieldnames=['AD_ID','feature'], delimiter='/')
                for element in Extra_Features:
                    writer.writerow({"AD_ID" : AD_ID,"feature" :  element})
        except:
            pass
        PHNO = None
        wait = WebDriverWait(driver, 10)
        clickity = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR,"#body-wrapper > div._1075545d.d059c029._4c726bfa._1709dcb4 > header:nth-child(3) > div > div > div > div._0a9bc591 > div._408759e3 > div:nth-child(2) > div > div._1075545d.b34f9439._42f36e3b._96d4439a._1709dcb4 > span._09eb0c84._79855a31" )))
        clickity.click()
        time.sleep(3)
        PHNO = driver.find_element(By.CSS_SELECTOR, "#body-wrapper > div > header:nth-child(3) > div > div > div > div._0a9bc591 > div._408759e3 > div:nth-child(2) > div > div._1075545d.b34f9439._42f36e3b._96d4439a._1709dcb4 > span").text
        row["Seller_Ph_No"] = PHNO
        join_date = None
        Name = None
        join_date = driver.find_element(By.CSS_SELECTOR, "#body-wrapper > div > header:nth-child(3) > div > div > div > div._0a9bc591 > div._408759e3 > div:nth-child(2) > div > a > div > div._1075545d._6caa7349._42f36e3b.d059c029 > div._05330198 > span").text.removeprefix("Member since ")

        Name = driver.find_element(By.CSS_SELECTOR, "#body-wrapper > div > header:nth-child(3) > div > div > div > div._0a9bc591 > div._408759e3 > div:nth-child(2) > div > a > div > div._1075545d._6caa7349._42f36e3b.d059c029 > span").text
        with open("Z:\DB\PROJECT\owners.csv", 'a', newline='', encoding='utf-8') as owner:
            writer = csv.DictWriter(owner,fieldnames=['Name','Join','PHNO'], delimiter='/')
            writer.writerow({'Name' : Name, "Join" : join_date, "PHNO" : PHNO})
        with open("Z:\DB\PROJECT\Car_ADs.csv", 'a', newline='', encoding='utf-8') as cars:
            writer = csv.DictWriter(cars,fieldnames=row.keys(), delimiter= '/')
            writer.writerow(row)
        numbers = []
        words = desc.splitlines()
        for word in words:
            num3 = ""
            if "01" in word:
                for c in word:
                    if c.isdigit():
                        num3 = num3 + c
            if len(num3) == 11:
                numbers.append(num3)
        if len(numbers) != 0:
            with open("Z:\DB\PROJECT\PHnumbers.csv","a",newline="") as ownernums : 
                writer = csv.DictWriter(ownernums, fieldnames= ['Primary Phone Number','Extra Phone Number'], delimiter='/')
                for num in numbers : 
                    writer.writerow({'Primary Phone Number' : PHNO , 'Extra Phone Number' : num})
    except:
        continue



        
        