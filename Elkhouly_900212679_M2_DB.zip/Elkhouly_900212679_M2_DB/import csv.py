import csv
import pandas as pd
import time
import pyarabic.araby as araby
import pyarabic.number as number

out = []
with open("Z:\DB\PROJECT\owners.csv", 'r', newline='', encoding='utf-8-sig') as f:
    reader = csv.reader(f)
    for row in reader:
        parts = row[0].split("/")
        out.append([parts[0], str(pd.to_datetime(parts[1], errors='coerce'))[0:11], parts[2]])
        #out.append([row[0], row[1], str(pd.to_datetime(row[2], errors='coerce'))[0:11]])

with open("Z:\DB\PROJECT\owners.csv", 'w', newline='', encoding='utf-8-sig') as f:
    writer = csv.writer(f)
    writer.writerows(out)