import pandas as pd
import csv 
from faker import Faker

personaluser=Faker()
birthdate=[]
emailAddress=[]
username=[]
gender=[]
for i in range(10):
    
    BD=personaluser.date_of_birth(minimum_age=18, maximum_age=65)
    birthdate.append(BD)
    emailA=personaluser.email(domain=personaluser.domain_name())
    emailAddress.append(emailA)
    user=personaluser.user_name()
    username.append(user)
    femaleMale = personaluser.random.choice(['F', 'M'])
    gender.append(femaleMale)
    
birthdf=pd.DataFrame(birthdate, columns=['birthdate'])
userdf=pd.DataFrame(username, columns=['username'])
emaildf=pd.DataFrame(emailAddress, columns=['emailAddress'])
genderdf=pd.DataFrame(gender, columns=['Gender'])

userfile = pd.concat([birthdf,userdf,emaildf,genderdf], axis=1)
userfile.to_csv("PersonalUsers.csv", sep=',', encoding='utf-8-sig', index=False)